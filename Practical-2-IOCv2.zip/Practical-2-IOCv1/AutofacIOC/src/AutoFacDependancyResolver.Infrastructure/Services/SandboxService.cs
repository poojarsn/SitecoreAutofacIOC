﻿using AutofacDependancyResolver.Core;

namespace AutofacDependancy.Infrastructure
{
    public class SandboxService : ISandboxService
    {
        public string GetFieldName()
        {
            return "DatasourceIDs";
        }
    }
}