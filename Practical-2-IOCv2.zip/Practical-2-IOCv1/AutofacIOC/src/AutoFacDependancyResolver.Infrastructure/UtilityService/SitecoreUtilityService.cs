using System;
using AutofacDependencyResolver.Domain;
using Glass.Mapper.Sc;
using Sitecore;
using AutofacDependancyResolver.Core;


namespace AutofacDependancy.Infrastructure
{
    public class SitecoreUtilityService : ISitecoreUtilityService
    {
        private readonly ISitecoreService _sitecoreService;

        public SitecoreUtilityService(ISitecoreService sitecoreService)
        {
            _sitecoreService = sitecoreService;
        }

        public string GetItemUrlById(Guid id)
        {
            var item = _sitecoreService.GetItem<SitecoreItem>(id);
            if (item != null)
            {
                return item.SitecoreItemUrl;
            }

            return string.Empty;
        }
        public string GetSiteRoot()
        {
            return Context.Site.RootPath;
        }

    }
}
