
using System;
using System.Collections.Generic;
using System.Globalization;


using AutofacDependancyResolver.Core;
using AutofacDependencyResolver.Domain;
using AutoFacDependencyResolver.Repository;
using Sitecore.ContentSearch.Linq.Common;

namespace AutofacDependancy.Infrastructure
{
    public class Settings : ISettings
    {
        private readonly IRepository<DisplaySettings> _displaySettingsRepository;

        private readonly ISitecoreUtilityService _sitecoreUtilityService;
        public Settings(IRepository<DisplaySettings> displaySettingsRepository,ISitecoreUtilityService sitecoreUtilityService )
        {
            _displaySettingsRepository = displaySettingsRepository;
            _sitecoreUtilityService    = sitecoreUtilityService;
        }
    
        /// <summary>
        /// This appsettings can be conffigured in xml <setting name value pair and can be refered from infra- reflection.
        /// </summary>
        /// <returns></returns>
        public DisplaySettings GetDisplaySettings()
        {
            //return _displaySettingsRepository.Get(_sitecoreUtilityService.GetSiteRoot() + _appSettings.DisplaySettingsRelativePath);
            return _displaySettingsRepository.Get(_sitecoreUtilityService.GetSiteRoot() + "/Configuration/Display-Settings");
        }      
    }
}
