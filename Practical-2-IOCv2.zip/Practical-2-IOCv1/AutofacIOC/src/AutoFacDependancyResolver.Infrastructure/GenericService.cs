using AutofacDependencyResolver.Domain;
using AutoFacDependencyResolver.Repository;
using System;
using System.Collections.Generic;
using System.Linq;


namespace AutofacDependancy.Infrastructure
{
	public class GenericService<TDomain> : IGenericService<TDomain> where TDomain : SitecoreItem
	{
		private readonly IRepository<TDomain> _repository;

		public GenericService(IRepository<TDomain> repository)
		{
			_repository = repository;
		}

		public TDomain Get(Guid itemId)
		{
			return _repository.Get(itemId);
		}

		public IEnumerable<TDomain> GetAll(Guid parentItemId)
		{
			return _repository.GetAll(parentItemId);
		}

        public IEnumerable<TDomain> GetAll(Guid parentItemId, Guid templateId)
        {
            var items = GetAll(parentItemId).Where(item => item.SitecoreTemplateId == templateId);
            return items;
        }
	}
}