using AutofacDependancyResolver.Core;
using AutofacDependencyResolver.Domain;
using AutoFacDependencyResolver.Repository;
using Sitecore.ContentSearch.Linq.Common;
using System;
using System.Collections.Generic;

namespace AutofacDependancy.Infrastructure
{
    public class BlogService : IBlogService
    {
        private readonly IBlogRepository            _blogRepository;
        private readonly IBlogCateogryRepository    _blogCategoryRepository;
  
        public BlogService(IBlogRepository blogRepository, IBlogCateogryRepository blogCategoryRepository) 
        {               
            _blogRepository             = blogRepository;
            _blogCategoryRepository    = blogCategoryRepository;
        }

        #region Demo Example
        public IEnumerable<BlogCategory> GetBlogCategory(Guid parentItemId)
        {
            return _blogCategoryRepository.GetBlogCategory(parentItemId);
        }

        public IEnumerable<BlogItem> GetAllBlogs(Guid parentItemId)
        {
            return _blogRepository.GetAllBlogs(parentItemId);
        }

        public IEnumerable<BlogItem> GetAllUnIndexedBlogsList(Guid parentItemId)
        {
            return _blogRepository.GetAllBlogsList(parentItemId);
        }

        public BlogItem FindBlogById(Guid id)
        {
            return _blogRepository.Get(id);
        }
        #endregion

        #region Yet to Explore
        public PagedSearchResult<BlogItem> GetPagedResult(Guid parentId, string type, string value, int pageIndex, int pageSize)
        {
            if (!string.IsNullOrWhiteSpace(value))
            {
                value = value.ToLower().Replace(" ", "");
                if (type == "category")
                {
                    return _blogRepository.GetBlogByCategory(parentId, value, pageIndex, pageSize, a => a.RawPostDate,
                                    SortDirection.Descending);                    
                }
                if (type == "date")
                {
                    return _blogRepository.GetRelatedBlogByDate(parentId, value, pageIndex, pageSize, a => a.RawPostDate,
                                    SortDirection.Descending);
                }
                return _blogRepository.GetBlogByTag(parentId, value, pageIndex, pageSize, a => a.RawPostDate,
                    SortDirection.Descending);
            }

			return _blogRepository.GetPagedResult(parentId, pageIndex, pageSize,a=>a.RawPostDate,SortDirection.Descending);
        }
            
        public PagedSearchResult<BlogItem> FindRelatedBlogByCategory(Guid id, string value, int pageIndex, int pageSize)
        {
            return _blogRepository.GetRelatedBlogByCategory(id, value, pageIndex, pageSize, a => a.RawPostDate,
                                    SortDirection.Descending);
        }
        #endregion
    }
}
