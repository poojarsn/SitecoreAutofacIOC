﻿using Sitecore.Data.Items;
using Sitecore.Web.UI.WebControls;
using System.Web.Mvc;

namespace AutofacDependancy.Web
{
    public class WYSIWYG
    {
        public Item Item { get; set; }

        public MvcHtmlString Content 
        { 
            get
            {
                return GetFieldValue("content");
            }
            set { ;}
        }

        private MvcHtmlString GetFieldValue(string fieldName)
        {
            return new MvcHtmlString(FieldRenderer.Render(Item, fieldName));
        }        
    }
}