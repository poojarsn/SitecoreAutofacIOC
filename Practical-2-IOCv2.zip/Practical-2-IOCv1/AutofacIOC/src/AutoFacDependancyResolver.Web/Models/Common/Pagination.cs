namespace AutofacDependancy.Web
{
	public class Pagination
	{
		public int PageIndex { get; set; }
		public int PageCount { get; set; }
		public int ItemCount { get; set; }
		public int PageSize { get; set; }
		public string Url { get; set; }
	}
}