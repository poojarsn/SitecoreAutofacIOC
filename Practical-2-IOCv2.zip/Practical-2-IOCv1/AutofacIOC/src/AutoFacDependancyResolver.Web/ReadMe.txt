﻿/-----------------------Glass Mapper-----------------------------
Install Glass Mapper
PM>  Install-Package Glass.Mapper.Sc 
in AutofacDependency.Web and you can reuse Glass.Mapper dlls in domain other referenced dll.

/------------------------------------Autofac-----------------------
Install Autofac Dependency using Nuget.. U will get latest Configuration.
unders AutofacDependancy.DepResolution

Resolve System.web.MVC either removing Assembly at runtime  or change the old and major version