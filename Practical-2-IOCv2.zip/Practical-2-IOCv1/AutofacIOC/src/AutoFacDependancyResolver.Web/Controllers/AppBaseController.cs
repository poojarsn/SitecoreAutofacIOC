
using System.Web.Mvc;
using Autofac;
using Autofac.Integration.Mvc;
using AutofacDependancyResolver.Core;
using Sitecore.Mvc.Controllers;

using Sitecore.Mvc.Controllers;

namespace AutofacDependancyResolver.Web.Controllers
{
    public abstract class AppBaseController : SitecoreController
    {
     
        protected AppBaseController()
        {
            //Can initialize global configuration such as display settings.. 
            //browser upgrade message
            //Default page size etc.
            //Caurosal or banner configuration
            //Accessibility
            //header or footer.
        }
    }
}