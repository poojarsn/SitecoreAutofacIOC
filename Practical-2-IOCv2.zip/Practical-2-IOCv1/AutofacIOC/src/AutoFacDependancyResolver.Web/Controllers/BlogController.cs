using Autofac;
using Autofac.Integration.Mvc;
using Sitecore.Mvc.Presentation;
using System;
using System.Globalization;
using System.Linq;
using System.Web.Mvc;
using AutofacDependancyResolver.Core;

using AutofacDependencyResolver.Domain;
using AutofacDependancy.Infrastructure;
using System.Collections.Generic;

using Glass.Mapper.Sc;
using Sitecore;
using Sitecore.Links;
//using AutoFacDependencyResolver.Repository;

namespace AutofacDependancyResolver.Web.Controllers
{
    public class BlogController : AppBaseController
    {
        private static readonly System.Guid CategoryID = new Guid("{27E10BBE-C757-4C6F-BCFB-0EC7B529DB82}");
        
        private readonly IBlogService                   _blogService;                             
        private readonly ISitecoreUtilityService        _sitecoreUtilityService;
        private readonly ISettings                      _settings;   

        public BlogController(IBlogService blogService)
        {
            _blogService = blogService;
        }            

        public ActionResult BlogIndexList()
        {
            var parentId = PageContext.CurrentOrNull.Item.ID.Guid;    
            
            var blogList = _blogService.GetAllBlogs(parentId);     
            
            return View("~/Views/Blog/BlogIndexList.cshtml", blogList);
        }

        public ActionResult BlogList()
        {
            var parentId = PageContext.CurrentOrNull.Item.ID.Guid;                 
            var blogList = _blogService.GetAllUnIndexedBlogsList(parentId);
            return View("~/Views/Blog/BlogList.cshtml", blogList);
        }

        public ActionResult BlogDetail()
        {
            var parentId = PageContext.CurrentOrNull.Item.ID.Guid;
            var blogList = _blogService.FindBlogById(parentId);
            return View("~/Views/Blog/BlogDetail.cshtml", blogList);
        }
        public ActionResult BlogCategoryList()
        {           
            var parentId = PageContext.CurrentOrNull.Item.ID.Guid;                    
            var blogCategory = _blogService.GetBlogCategory(CategoryID);
            Sitecore.Diagnostics.Log.Info("CategorySelect", blogCategory.Select(a => a.CategoryType));            
            return View("~/Views/Blog/BlogCategoryList.cshtml", blogCategory);
        }

        #region Yet to explore
        public DisplaySettings DisplaySettings
        {
            get { return _settings.GetDisplaySettings(); }
        }

        public ActionResult BlogRelated()
        {
            Guid blogItemId;
            var isValidBannerItem = Guid.TryParse(RenderingContext.CurrentOrNull.Rendering.DataSource, out blogItemId);
            if (!isValidBannerItem)
            {
                return View();
            }
            var blogItem = _blogService.FindBlogById(blogItemId);
            var displaySetting = _settings.GetDisplaySettings();
            ViewBag.ReadMoreText = displaySetting.BlogReadMoreText;
            return View(blogItem);
        }
#endregion
    }
}