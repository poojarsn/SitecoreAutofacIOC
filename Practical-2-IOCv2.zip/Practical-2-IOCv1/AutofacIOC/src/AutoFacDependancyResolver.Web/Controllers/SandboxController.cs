﻿using System.Web.Mvc;
using AutofacDependancyResolver.Core;
using Sitecore.Mvc.Controllers;
using AutofacDependancy.Web;
using Sitecore.Collections;
using Sitecore.Data.Items;
using Sitecore.Mvc.Presentation;
using System.Collections.Generic;
using System.Linq;

namespace AutofacDependancyResolver.Web.Controllers
{
    public class SandboxController : SitecoreController
    {
        private readonly ISandboxService _sandboxService;

        public SandboxController(ISandboxService sandboxService)
        {
            _sandboxService = sandboxService;
        }

        public ActionResult SandboxAction()
        {            
            var item = Sitecore.Mvc.Presentation.RenderingContext.Current.Rendering.Item;
            var rcTreeItemIds = Sitecore.Data.ID.ParseArray(item[_sandboxService.GetFieldName()]);

            var rc = new RichContextTextsViewModel
            {
                WYSIWYGs = rcTreeItemIds.Select(i =>
                        new WYSIWYG
                        {
                            Item = item.Database.GetItem(i)
                        }).ToList()
            };           
            return  View("~/Views/Shared/ContentRichText.cshtml",rc.WYSIWYGs);
        }
        private Item GetDataSource()
        {
            if (Sitecore.Context.Database == null
                || RenderingContext.CurrentOrNull == null
                || RenderingContext.Current.Rendering == null)
            {
                return null;
            }

            if (!string.IsNullOrEmpty(RenderingContext.Current.Rendering.DataSource))
            {
                return Sitecore.Context.Database.GetItem(RenderingContext.Current.Rendering.DataSource);
            }

            return Sitecore.Context.Item;
        }

    }
}