namespace AutofacDependancy.Web.Presentation.Utility
{
    public static class ValidationExpression
    {
        public const string Alphanumeric = @"^[a-zA-Z0-9_\s.]*$";
        public const string Email = @"^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$";
    }
}
