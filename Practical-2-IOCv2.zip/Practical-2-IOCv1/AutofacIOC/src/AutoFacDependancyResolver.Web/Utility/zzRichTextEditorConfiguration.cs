﻿using Sitecore.Data.Items;

namespace AutofacDependancy.Web.Presentation.Utility
{
    // Custom Rich text configuration to Telerik's rich text editor
    public class zzRichTextEditorConfiguration : Sitecore.Shell.Controls.RichTextEditor.EditorConfiguration
    {
        public zzRichTextEditorConfiguration(Item profile) : base(profile) { }

        // Setup stylesheets accordingly. WebStylesheet to the editor and WebStylesheetForLinks as a list os links classes available in properties.
        protected override void SetupStylesheets()
        {
            base.SetupStylesheets();
            //set the stylesheet used to list classes into the "Apply Class" dropdowns
            //base.Editor.CssFiles.Add(Sitecore.Configuration.Settings.GetSetting("zzWebStylesheet"));
        }
    }
}