using System;
using System.Globalization;
using System.Web;
using Sitecore.Mvc.Helpers;
using Sitecore.Mvc.Presentation;

namespace AutofacDependancy.Web.Presentation.Utility
{
    public static class SitecoreHelperExtensions
	{
		/// <summary>
		///     todo: find better places for global date format in entire website
		/// </summary>
		private const string GlobalDateTimeFormat = "M.dd.yyyy";
			
        public static string FieldAsDate(this SitecoreHelper helper, string fieldName)
        {
            var date = helper.Field(fieldName).ToString();
			DateTime utcDate;
			return DateTime.TryParse(date, CultureInfo.CurrentUICulture, DateTimeStyles.None, out utcDate)
					   ? FormatDate(helper, utcDate)
					   : string.Empty;
		}

		/// <summary>
		///     todo: the goal is to make date time format same in all pages within the website,
		///     advise better techniques if any
		/// </summary>
		/// <param name="helper"></param>
		/// <param name="dateField"></param>
		/// <returns></returns>
		public static string FormatDate(this SitecoreHelper helper, DateTime dateField)
		{
			return dateField.ToString(GlobalDateTimeFormat);
		}

        public static HtmlString DynamicKeyPlaceholder(this SitecoreHelper helper, string key)
        {
            var currentRenderingId = RenderingContext.Current.Rendering.UniqueId;
            return helper.Placeholder(string.Format("{0}#{1}", key, currentRenderingId.ToString("N")));
        }
	}
}