using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace AutofacDependancy.Web.Presentation.Utility
{
	public static class StringUtility
	{
		public static DateTime? ConvertToDatetime(this string value)
		{
			DateTime tempDateTimeValue;
			if (!string.IsNullOrEmpty(value) && DateTime.TryParse(value, out tempDateTimeValue))
			{
				return tempDateTimeValue;
			}

			return null;

		}

        public static string ConvertDatetimeToDateWithSuffix(this DateTime? value)
        {
            if (value.HasValue)
            {
                var dt = value.Value;
                var removedDateFirstTrailZero = dt.ToString("dd").ConvertToInteger();
                var dateToDay = removedDateFirstTrailZero.ToString(CultureInfo.InvariantCulture);
                var firstCharDateToDay = dateToDay.Length > 1 ? dateToDay.Substring(1) : dateToDay;

                var suffix = "th";

                if (dt.Day == 11 || dt.Day == 12 || dt.Day == 13)
                {
                    suffix = "th";
                }
                else if (firstCharDateToDay == "1")
                {
                    suffix = "st";
                }
                else if (firstCharDateToDay == "2")
                {
                    suffix = "nd";
                }
                else if (firstCharDateToDay == "3")
                {
                    suffix = "rd";
                }

                return string.Format("{0}{1} {2} {3}", removedDateFirstTrailZero, suffix, dt.ToString("MMM"), dt.ToString("yyyy"));
            }

            return string.Empty;
        }

		public static DateTime? ConvertToDatetimeFromMonthName(this string value)
		{
			DateTime tempDateTimeValue;

			if (!string.IsNullOrEmpty(value) && DateTime.TryParseExact(value, "MMMM", CultureInfo.InvariantCulture, DateTimeStyles.None, out tempDateTimeValue))
			{
				return tempDateTimeValue;
			}

			return null;
		}

		public static int ConvertToInteger(this string value)
		{
			int tempIntValue;
			if (!string.IsNullOrEmpty(value) && int.TryParse(value, out tempIntValue))
			{
				return tempIntValue;
			}

			return 0;

		}

		public static Guid ConvertToGuid(this string value)
		{
			Guid tempGuidValue;
			if (!string.IsNullOrEmpty(value) && Guid.TryParse(value, out tempGuidValue))
			{
				return tempGuidValue;
			}

			return Guid.Empty;

		}

		public static IEnumerable<string> ExtractDelimitedToList(this string delimitedValue, char separatorChar)
		{
			if (!string.IsNullOrEmpty(delimitedValue))
			{
				var splittedValues = delimitedValue.Split(separatorChar);
				if (splittedValues.Any())
				{
					return splittedValues.ToList();
				}
			}

			return new List<string>();
		}

		public static string GetSubString(string words, int take)
		{
			try
			{
			    var dotString = (words.Length > take) ? "..." : string.Empty;
                  
				return string.Format("{0}{1}",words.Substring(0, take),dotString);
			}
			catch
			{
				return string.Empty;
			}
		}

        public static string ToRelativeDate(this DateTime dateTime)
        {
            const int second = 1;
            const int minute = 60 * second;
            const int hour = 60 * minute;
            const int day = 24 * hour;
            const int week = 7 * day;

            var ts = new TimeSpan(DateTime.Now.Ticks - dateTime.Ticks);
            double delta = Math.Abs(ts.TotalSeconds);

            if (delta < 0)
            {
                return "not yet";
            }
            if (delta < 1 * minute)
            {
                return ts.Seconds == 1 ? "one second ago" : ts.Seconds + " seconds ago";
            }
            if (delta < 2 * minute)
            {
                return "a minute ago";
            }
            if (delta < 45 * minute)
            {
                return ts.Minutes + " minutes ago";
            }
            if (delta < 90 * minute)
            {
                return "an hour ago";
            }
            if (delta < 24 * hour)
            {
                return ts.Hours + " hours ago";
            }
            if (delta < 48 * hour)
            {
                return "yesterday";
            }

            if (delta < 1 * week)
            {
                return ts.Days + " days ago";
            }

            if (delta < 30 * day)
            {
                int weeks = Convert.ToInt32(Math.Floor((double) ts.Days/7));
                return weeks <= 1 ? "one week ago" : weeks + " weeks ago";
            }
            if (delta > 30 * day)
            {
                var months = ConvertDatetimeToDateWithSuffix(dateTime); 
                return months;
            }
            else
            {
                return "not yet";
            }
        }
	}
}
