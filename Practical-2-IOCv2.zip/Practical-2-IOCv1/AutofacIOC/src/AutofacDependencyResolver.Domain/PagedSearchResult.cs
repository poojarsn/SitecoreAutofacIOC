using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace AutofacDependencyResolver.Domain
{
    public class PagedSearchResult
    {
        public int ItemCount { get; set; }
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
        public int PageCount
        {
            get { return (int)Math.Ceiling((double)ItemCount / PageSize); }
        }
    }
    public class PagedSearchResult<T> : PagedSearchResult where T : class
    {
        public PagedSearchResult()
        {
            Items = Enumerable.Empty<T>();
        }
        public IEnumerable<T> Items { get; set; }

        public int StartVisibleIndex
		{
			get
			{
				if (ItemCount <= 0)
				{
					return 0;
				}

				var pageIndex = PageIndex - 1;
				if (pageIndex < 0)
				{
					return 0;
				}

				return (pageIndex * PageSize) + 1;
			}
		}

		public int EndVisibleIndex
		{
			get
			{
				var value = StartVisibleIndex + base.PageSize - 1;
				if (value > ItemCount)
				{
					value = ItemCount;
				}
				return value;
			}
		}
	}
}