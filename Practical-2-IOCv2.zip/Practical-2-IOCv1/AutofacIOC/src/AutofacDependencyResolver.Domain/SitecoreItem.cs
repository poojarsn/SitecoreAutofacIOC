using System;
using System.ComponentModel;
using Glass.Mapper.Sc.Configuration;
using Glass.Mapper.Sc.Configuration.Attributes;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.Converters;

namespace AutofacDependencyResolver.Domain
{
    [SitecoreType(AutoMap = true)]
    public class SitecoreItem
    {
        [SitecoreId]
        [TypeConverter(typeof(IndexFieldIDValueConverter))]
        [IndexField("_group")]
        public Guid SitecoreItemId { get; set; }

        [SitecoreInfo(SitecoreInfoType.FullPath)]
        [IndexField("_fullpath")]
        public string SitecoreItemPath { get; set; }

        [SitecoreInfo(SitecoreInfoType.Url)]
        public string SitecoreItemUrl { get; set; }

        [SitecoreInfo(SitecoreInfoType.Name)]
        public string SitecoreItemName { get; set; }

        [SitecoreInfo(SitecoreInfoType.DisplayName)]
        public string SitecoreDisplayName { get; set; }

        [SitecoreInfo(SitecoreInfoType.Version)]
        public int SitecoreItemVersion { get; set; }

        [SitecoreInfo(SitecoreInfoType.TemplateId)]
        [TypeConverter(typeof(IndexFieldIDValueConverter))]
        [IndexField("_template")]
        public Guid SitecoreTemplateId { get; set; }

        [SitecoreInfo(SitecoreInfoType.TemplateName)]
        [IndexField("_templatename")]
        public string SitecoreTemplateName { get; set; }

        [SitecoreField(FieldName = "__Created by")]
        public string Creator { get; set; }

        [SitecoreIgnore]
        public string SitecoreItemCreator
        {
            get
            {
                var normalizedName = Creator.Split('\\');
                if (normalizedName.Length == 2) return normalizedName[1];
                return string.Empty;
            }
        }
    }
}
