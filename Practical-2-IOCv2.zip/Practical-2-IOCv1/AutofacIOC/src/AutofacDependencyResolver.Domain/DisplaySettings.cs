using System;
using System.Collections.Generic;
using Glass.Mapper.Sc.Configuration;
using Glass.Mapper.Sc.Configuration.Attributes;
using Glass.Mapper.Sc.Fields;

namespace AutofacDependencyResolver.Domain
{
    public class DisplaySettings : SitecoreItem
    {
        [SitecoreField(FieldName="list page size", FieldType= SitecoreFieldType.Integer)]
        public int ListPageSize { get; set; }

        [SitecoreField(FieldName = "Blog Category Folder", FieldType = SitecoreFieldType.DropTree)]
        public Guid BlogCategoryFolder { get; set; }

        [SitecoreField(FieldName = "Blog Listing Page", FieldType = SitecoreFieldType.GeneralLink)]
        public Link BlogListingPage { get; set; }

        [SitecoreField(FieldName = "Blog Archieve Page", FieldType = SitecoreFieldType.GeneralLink)]
        public Link BlogArchievePage { get; set; }

        [SitecoreField(FieldName = "Blog Read More Text", FieldType = SitecoreFieldType.SingleLineText)]
        public string BlogReadMoreText { get; set; }
    }
}
