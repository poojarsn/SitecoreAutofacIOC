using System.Collections.Generic;
using Glass.Mapper.Sc.Configuration.Attributes;

namespace AutofacDependencyResolver.Domain
{
	[SitecoreType(AutoMap = true)]
	public class FolderItem<T> : SitecoreItem where T:class 
	{
		[SitecoreChildren(IsLazy = false)]
		public IEnumerable<T> Children { get; set; }
	}
}
