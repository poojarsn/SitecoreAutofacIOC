﻿using System.Collections.Generic;
using Glass.Mapper.Sc.Configuration;
using Glass.Mapper.Sc.Configuration.Attributes;
using Glass.Mapper.Sc.Fields;

namespace AutofacDependencyResolver.Domain
{
    [SitecoreType(AutoMap = true)]
    public class BlogCategory : SitecoreItem
    {
        [SitecoreField(FieldName = "CategoryType", FieldType = SitecoreFieldType.SingleLineText)]
        public string CategoryType { get; set; }
    }
}
