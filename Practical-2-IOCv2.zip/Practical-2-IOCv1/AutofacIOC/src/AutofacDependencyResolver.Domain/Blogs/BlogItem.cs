using System;
using System.Collections.Generic;
using System.Globalization;
using Glass.Mapper.Sc.Configuration;
using Glass.Mapper.Sc.Configuration.Attributes;
using Glass.Mapper.Sc.Fields;
using Sitecore.ContentSearch;

namespace AutofacDependencyResolver.Domain
{
    [SitecoreType(AutoMap = true)]
    public class BlogItem : WYSIWYG
    {

        [SitecoreField("Author")]
        public string Author { get; set; }

        [SitecoreField("Title")]
        public string BlogTitle { get; set; }

        [SitecoreField("Summary")]
        public string Summary { get; set; }

        [SitecoreField("Image", FieldType = SitecoreFieldType.Image)]
        public Image TrendingImage { get; set; }

        [SitecoreField(FieldName = "Category", FieldType = SitecoreFieldType.Multilist, Setting = SitecoreFieldSettings.DontLoadLazily)]
        public IEnumerable<BlogCategory> Categories { get; set; }
        
        [SitecoreField(FieldName = "PostDate", FieldType = SitecoreFieldType.DateTime)]
        public DateTime PostDate { get; set; }

        //[SitecoreField(FieldName = "blog tags", FieldType = SitecoreFieldType.Multilist, Setting = SitecoreFieldSettings.DontLoadLazily)]
        //public IEnumerable<Tag> Tags { get; set; }

        [SitecoreIgnore]
        [IndexField("Blog_Image")]
        public string BlogImage { get; set; }

        [SitecoreIgnore]
        [IndexField("Blog_Summary")]
        public string BlogSummary { get; set; }

        [SitecoreIgnore]
        [IndexField("Blog_Title")]
        public string Title { get; set; }

        [SitecoreIgnore]
        [IndexField("__categories")]
        public string RawCategories { get; set; }

        [SitecoreField("Background Colour")]
        public string BackgroundColor { get; set; }

        [SitecoreIgnore]
        [IndexField("Post_Date")]
        public string RawPostDate { get; set; }

        [SitecoreIgnore]
        public DateTime RawPostDateParsed
        {
            get
            {
                var postDate = DateTime.MinValue;
                if (DateTime.TryParseExact(RawPostDate, "yyyyMMddTHHmmss", CultureInfo.InvariantCulture,
                       DateTimeStyles.None, out postDate))
                {
                    return postDate;
                }
                return DateTime.MinValue;
            }
        }          
    }
}
