using Glass.Mapper.Sc.Configuration;
using Glass.Mapper.Sc.Configuration.Attributes;

namespace AutofacDependencyResolver.Domain
{
    [SitecoreType(AutoMap = true)]
    public class WYSIWYG : SitecoreItem
    {
        [SitecoreField(FieldType = SitecoreFieldType.RichText)]
        public string Content { get; set; }
    }
}