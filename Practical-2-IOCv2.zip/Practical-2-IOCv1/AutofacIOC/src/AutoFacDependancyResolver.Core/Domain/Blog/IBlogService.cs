using System;
using System.Collections.Generic;
using AutofacDependencyResolver.Domain;

namespace AutofacDependancyResolver.Core
{
    public interface IBlogService
    {                              
          IEnumerable<BlogItem> GetAllBlogs(Guid parentItemId);
          IEnumerable<BlogCategory> GetBlogCategory(Guid parentItemId);
          IEnumerable<BlogItem> GetAllUnIndexedBlogsList(Guid parentItemId);
          BlogItem FindBlogById(Guid id);
          //-----------------------------TBD--------/  
          
          PagedSearchResult<BlogItem> FindRelatedBlogByCategory(Guid id, string value, int pageIndex, int pageSize);
          PagedSearchResult<BlogItem> GetPagedResult(Guid parentId, string type, string value, int pageIndex, int pageSize);
    
    }
}
