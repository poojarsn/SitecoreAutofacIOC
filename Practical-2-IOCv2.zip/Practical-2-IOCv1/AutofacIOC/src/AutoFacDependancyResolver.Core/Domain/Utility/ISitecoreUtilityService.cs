using System;

namespace AutofacDependancyResolver.Core
{
    public interface ISitecoreUtilityService
    {
        string GetItemUrlById(Guid id);
        string GetSiteRoot();
    }
}
