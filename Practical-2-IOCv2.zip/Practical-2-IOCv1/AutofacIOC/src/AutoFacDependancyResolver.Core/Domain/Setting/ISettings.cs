using AutofacDependencyResolver.Domain;

namespace AutofacDependancyResolver.Core
{
    public interface ISettings
    {
        DisplaySettings GetDisplaySettings();     
    }
}
