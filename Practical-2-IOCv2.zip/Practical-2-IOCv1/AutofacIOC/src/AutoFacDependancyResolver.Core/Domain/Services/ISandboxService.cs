﻿namespace AutofacDependancyResolver.Core
{
    public interface ISandboxService
    {
        string GetFieldName();
    }
}