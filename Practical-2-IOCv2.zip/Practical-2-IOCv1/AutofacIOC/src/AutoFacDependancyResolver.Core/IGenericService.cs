using AutofacDependencyResolver.Domain;
using System;
using System.Collections.Generic;

namespace AutofacDependancy.Infrastructure
{
	public interface IGenericService<TDomain> where TDomain : SitecoreItem
	{
		TDomain Get(Guid itemId);
		IEnumerable<TDomain> GetAll(Guid parentItemId);
	    IEnumerable<TDomain> GetAll(Guid parentItemId, Guid templateId);
	}
}