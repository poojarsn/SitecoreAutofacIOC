﻿using System.Web.UI.WebControls;
using Sitecore;
using Sitecore.Data.Fields;
using Sitecore.Data.Items;
using Sitecore.Events;
using Sitecore.Layouts;
using System;
using System.Linq;
using Sitecore.Web.UI.WebControls;

namespace AutofacDependancy.CMS.WebModule.Events
{
    public class RemoveUnusedRenderingReference
    {
        public void OnItemSaving(object sender, EventArgs args)
        {
            var item = Event.ExtractParameter(args, 0) as Item;
            if (item == null || !item.Database.Name.Equals("master", StringComparison.InvariantCultureIgnoreCase))
            {
                return;
            }

            var layoutField = new LayoutField(item.Fields[FieldIDs.LayoutField]);
            if (!layoutField.InnerField.HasValue)
            {
                return;
            }

            var existingItem = item.Database.GetItem(item.ID, item.Language, item.Version);
            if (existingItem == null)
            {
                return;
            }

            var oldLayoutField = new LayoutField(existingItem.Fields[FieldIDs.LayoutField]);

            if (string.IsNullOrEmpty(layoutField.Value) || string.IsNullOrEmpty(oldLayoutField.Value) ||
                layoutField.Value == oldLayoutField.Value)
            {
                return;
            }

            var layout = LayoutDefinition.Parse(layoutField.Value);
            var oldLayout = LayoutDefinition.Parse(oldLayoutField.Value);
            var devices = layout.Devices.Cast<DeviceDefinition>().ToList();
            foreach (var device in devices)
            {
                var oldDevice = oldLayout.Devices.Cast<DeviceDefinition>().FirstOrDefault(x => x.ID == device.ID);
                if (oldDevice == null)
                {
                    continue;
                }

                var renderings = device.Renderings.Cast<RenderingDefinition>().ToList();
                var oldRenderings = oldDevice.Renderings.Cast<RenderingDefinition>().ToList();
                var deletedRenderings = oldRenderings.Where(rendering => !layoutField.Value.Contains(rendering.UniqueId)).ToList();
                var deletedSubRenderings = oldRenderings.Where(rendering => !layoutField.Value.Contains(rendering.UniqueId)).ToList();

                foreach (var deletedRendering in deletedRenderings)
                {
                    var deletedRenderingId = new Guid(deletedRendering.UniqueId);
                    var deletedRenderingDatasourceItem = item.Database.GetItem(deletedRendering.Datasource);
                    var deletedRenderingDatasourceItemId = deletedRenderingDatasourceItem.ID.ToGuid().ToString("N");
                    var deletedRenderingDatasourceChildrenIds = deletedRenderingDatasourceItem.Children.Select(child => child.ID.ToGuid().ToString("N")).ToList();

                    foreach (var rendering in renderings)
                    {
                        var isContainingDynamicPlaceholder =
                            rendering.Placeholder.Contains(deletedRenderingId.ToString("N"));
                        var isContainingDatasourceItemId =
                            rendering.Placeholder.Contains(deletedRenderingDatasourceItemId);
                        var isContainingDatasourceChildrenItemId =
                            deletedRenderingDatasourceChildrenIds.Any(id => rendering.Placeholder.Contains(id));

                        if (isContainingDynamicPlaceholder || isContainingDatasourceItemId || isContainingDatasourceChildrenItemId)
                        {
                            deletedSubRenderings.Add(rendering);
                        }
                    }
                }


                foreach (var deletedSubRendering in deletedSubRenderings)
                {
                    device.Renderings.Remove(deletedSubRendering);
                }
            }

            

            item.Fields[FieldIDs.LayoutField].Value = layout.ToXml();
            //var unusedRenderings =
            //    renderings.Where(
            //        rendering =>
            //            deletedRenderings.Any(deletedRendering => ContainsUniqueId(rendering, deletedRendering)))
            //        .ToList();
            //deletedRenderings.AddRange(unusedRenderings);

            //var deletedRelatedRenderings =
            //    renderings.Where(
            //        rendering =>
            //            deletedRenderings.Any(deletedRelatedRendering => ContainsUniqueId(rendering, deletedRelatedRendering)))
            //        .ToList();
            //deletedRenderings.AddRange(deletedRelatedRenderings);
        }

        private static bool ContainsUniqueId(RenderingDefinition rendering, RenderingDefinition deletedRendering)
        {
            var uniqueGuid = new Guid(deletedRendering.UniqueId);
            var uniqueId = uniqueGuid.ToString("N");

            return rendering.Placeholder.Contains(uniqueId);
        }


        //private static void DeleteDataSource(RenderingDefinition rendering, Item item)
        //{
        //    if (string.IsNullOrEmpty(rendering.Datasource))
        //    {
        //        return;
        //    }

        //    var datasourceItem = item.Database.GetItem(rendering.Datasource);
        //    if (datasourceItem == null)
        //    {
        //        return;
        //    }

        //    var refererrs = Globals.LinkDatabase.GetReferrers(datasourceItem);
        //    if (!refererrs.Any() || refererrs.All(x => IsReferringItem(item, x)))
        //    {
        //        datasourceItem.Delete();
        //    }
        //}

        //private static bool IsReferringItem(Item item, ItemLink referrer)
        //{
        //    return referrer.SourceItemID == item.ID;
        //}
    }
}
