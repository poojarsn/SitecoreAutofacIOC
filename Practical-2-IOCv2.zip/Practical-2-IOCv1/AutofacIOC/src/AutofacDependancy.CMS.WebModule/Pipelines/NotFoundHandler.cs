using Sitecore;
using Sitecore.Pipelines.HttpRequest;

namespace AutofacDependancy.CMS.WebModule.Pipelines
{
    public class NotFoundHandler : HttpRequestProcessor
    {
        public override void Process(HttpRequestArgs args)
        {
            if (Context.Site == null
                || Context.Database == null
                || Context.Item != null
                || args.PermissionDenied)
            {
                return;
            }

            Context.Item = Context.Database.GetItem(Context.Site.RootPath
                + Context.Site.StartItem
                + Sitecore.Configuration.Settings.ItemNotFoundUrl);
        }
    }
}
