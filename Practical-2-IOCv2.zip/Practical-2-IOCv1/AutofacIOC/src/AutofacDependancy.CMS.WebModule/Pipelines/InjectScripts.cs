﻿using System.Web;
using System.Web.UI;
using Sitecore.Pipelines;

namespace AutofacDependancy.CMS.WebModule.Pipelines
{
    public class InjectScripts
    {
        public void Process(PipelineArgs args)
        {
            var url = HttpContext.Current.Request.Url.AbsolutePath;

            if (url.Contains("field%20editor") || url.Contains("field editor"))
            {
                AddScript("<script type=\"text/javascript\" src=\"/Assets/Rabo/Scripts/Lib/jquery-1.9.1.min.js\"></script>");
            }

            AddScript("<script type=\"text/javascript\">var $J = jQuery.noConflict();</script>");
            AddScript("<script type=\"text/javascript\" src=\"/Assets/FinancialService/Scripts/Lib/bootstrap.min.js\"></script>");
            AddScript("<script type=\"text/javascript\" src=\"/Assets/FinancialService/Scripts/Lib/bootstrap-colorselector.js\"></script>");
            AddScript("<link type=\"text/css\" href=\"/Assets/FinancialService/Styles/bootstrap-colorselector.css\" rel=\"stylesheet\" />");
            AddScript("<link type=\"text/css\" href=\"/Assets/FinancialService/Styles/sitecore-colorselector.css\" rel=\"stylesheet\" />");
        }

        private static void AddScript(string script)
        {
            Sitecore.Context.Page.Page.Header.Controls.Add(new LiteralControl(script));
        }
    }
}
