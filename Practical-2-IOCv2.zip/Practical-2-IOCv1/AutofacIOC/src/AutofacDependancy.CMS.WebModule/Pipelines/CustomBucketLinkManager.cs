﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Reflection;
using Sitecore;
using Sitecore.Buckets.Extensions;
using Sitecore.Buckets.Managers;
using Sitecore.Data.Items;
using Sitecore.Diagnostics;
using Sitecore.IO;
using Sitecore.Links;
using Sitecore.Sites;

namespace AutofacDependancy.CMS.WebModule.Pipelines
{
    public class CustomBucketLinkManager : LinkProvider
    {
        public CustomBucketLinkManager()
        {

        }

        public override void Initialize(string name, NameValueCollection config)
        {
            base.Initialize(name, config);
            InitializeSiteResolving(config);
        }

        public override string GetItemUrl(Item item, UrlOptions options)
        {
            if (BucketManager.IsItemContainedWithinBucket(item))
            {
                Item bucketItem = item.GetParentBucketItemOrParent();
                if (bucketItem != null && bucketItem.IsABucket())
                {
                    string bucketUrl = base.GetItemUrl(bucketItem, options);
                    if (options.AddAspxExtension)
                        bucketUrl = bucketUrl.Replace(".aspx", string.Empty);

                    return FileUtil.MakePath(bucketUrl, item.Name) +
                           (options.AddAspxExtension ? ".aspx" : string.Empty);
                }
            }

            return base.GetItemUrl(item, options);
        }

        private void InitializeSiteResolving(NameValueCollection config)
        {
            Assert.ArgumentNotNull(config, "config");
            FieldInfo urlOptionField = typeof(Sitecore.Links.LinkProvider).GetField("defaultUrlOptions",
                                                                                     BindingFlags.NonPublic |
                                                                                     BindingFlags.Instance);
            UrlOptions urlOptions = (UrlOptions)urlOptionField.GetValue(this);
            urlOptions.SiteResolving = MainUtil.GetBool(config["siteResolving"], false);
        }
    }
}