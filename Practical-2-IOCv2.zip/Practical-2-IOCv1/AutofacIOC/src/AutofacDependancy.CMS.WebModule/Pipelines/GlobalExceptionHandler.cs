using System.Web;
using System.Web.Configuration;
using Sitecore.Configuration;
using Sitecore.Diagnostics;
using Sitecore.Mvc.Pipelines.MvcEvents.Exception;

namespace AutofacDependancy.CMS.WebModule
{
    public class GlobalExceptionHandler : ExceptionProcessor
    {
        public override void Process(ExceptionArgs args)
        {
            Log.Error(
                "MVC exception processing " + Sitecore.Context.RawUrl,
                args.ExceptionContext.Exception,
                this);

            CustomErrorsMode mode = Settings.CustomErrorsMode;
            if (mode == CustomErrorsMode.Off
                // to show details to Sitecore admins: || SC.Context.User.IsAdministrator 
                // to show in the Page Editor: || SC.Context.PageMode.IsPageEditor
                // to show in Preview: || SC.Context.PageMode.IsPreview
                // to show in the debugger: || SC.Context.PageMode.IsDebugging
              || (mode == CustomErrorsMode.RemoteOnly && HttpContext.Current.Request.IsLocal))
            {
                return;
            }

            HttpContext.Current.Response.Clear();
            Sitecore.Web.WebUtil.Redirect(Settings.ErrorPage.Replace("[site]", Sitecore.Context.Site.Name));
            args.ExceptionContext.ExceptionHandled = true;
        }
    }
}
