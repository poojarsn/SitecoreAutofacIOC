using System.Net;
using System.Web;
using Sitecore;
using Sitecore.Configuration;
using Sitecore.Diagnostics;
using Sitecore.Resources.Media;
using Sitecore.SecurityModel;

namespace AutofacDependancy.CMS.WebModule.Pipelines
{
    public class MediaRequestHandler : Sitecore.Resources.Media.MediaRequestHandler
    {
        protected override bool DoProcessRequest(HttpContext context)
        {
            Assert.ArgumentNotNull(context, "context");
            MediaRequest mediaRequest = MediaManager.ParseMediaRequest(context.Request);
            if (mediaRequest == null)
            {
                return false;
            }
            Media media = MediaManager.GetMedia(mediaRequest.MediaUri);
            if (media == null)
            {
                using (new SecurityDisabler())
                {
                    media = MediaManager.GetMedia(mediaRequest.MediaUri);
                }
                HttpContext.Current.Response.Clear();
                if (media == null)
                {
                    HttpContext.Current.Response.StatusCode = (int)HttpStatusCode.NotFound;
                }
                else
                {
                    Assert.IsNotNull(Context.Site, "site");
                    var text = ((Context.Site.LoginPage != string.Empty) 
                        ? Context.Site.LoginPage 
                        : Settings.NoAccessUrl);
                    if (Settings.RequestErrors.UseServerSideRedirect)
                    {
                        HttpContext.Current.Server.Transfer(text);
                    }
                    else
                    {
                        HttpContext.Current.Response.Redirect(text);
                    }
                }
                return true;
            }
            return DoProcessRequest(context, mediaRequest, media);
        }
    }
}
