﻿using System.Linq;
using Sitecore;
using Sitecore.Buckets.Managers;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.SearchTypes;
using Sitecore.Data.Items;
using Sitecore.Pipelines.HttpRequest;

namespace AutofacDependancy.CMS.WebModule.Pipelines
{
    /// <summary>
    /// https://adeneys.wordpress.com/2013/07/19/item-buckets-and-urls/
    /// http://sitecoreblog.alexshyba.com/sitecore_product_urls_amazon_style/
    /// </summary>
    public class CustomBucketItemResolver : HttpRequestProcessor
    {
        public override void Process(HttpRequestArgs args)
        {
            if (Context.Item == null)
            {
                string requestUrl = args.Url.ItemPath;

                // remove last element from path and see if resulting path is a bucket
                int index = requestUrl.LastIndexOf('/');
                if (index > 0)
                {
                    string bucketPath = requestUrl.Substring(0, index);
                    Item bucketItem = args.GetItem(bucketPath);
                    
                    //Blog Home -Item ID {4AD96E9B-5EDF-4528-B572-716D5A08B47E}
                    //TemplateID-
                    if (bucketItem != null && bucketItem.TemplateID.ToString().Equals("{EF404D98-151B-4414-996B-4D006AD6303D}") && BucketManager.IsBucket(bucketItem))
                    {
                        string itemName = requestUrl.Substring(index + 1);

                        // locate item in bucket by name
                        using (var searchContext = ContentSearchManager.GetIndex("zz_web_index").CreateSearchContext())
                        {
                            SearchResultItem result = searchContext.GetQueryable<SearchResultItem>()
                                                                   .FirstOrDefault(x => x.Name == itemName);
                            if (result != null)
                                Context.Item = result.GetItem();
                        }
                    }
                }
            }
        }
    }
}