using System.Collections.Generic;
using System.Linq;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.ComputedFields;
using Sitecore.Data;

namespace AutofacDependancy.CMS.WebModule.Search.ComputedFields
{
    public class CategoryField : IComputedIndexField
    {
        /// <summary>
        /// "Category" Field name within Blog Post. Get the list of Item
        /// Fetch all Item ids, then get the CategoryType Name from actual item.
        /// Form String Category Name array for that indexed Item of blog post.[SitecoreIndexableItem]
        /// </summary>
        /// <param name="indexable"></param>
        /// <returns></returns>
        public object ComputeFieldValue(IIndexable indexable)
        {
            var item = indexable as SitecoreIndexableItem;
            if (item == null) return string.Empty;

            var db = item.Item.Database;
            Sitecore.Diagnostics.Log.Debug("DB", db.Name);
            var blogCategory = item.GetFieldByName("Category");
            Sitecore.Diagnostics.Log.Info("Category", blogCategory.Value);

            if (blogCategory == null) return string.Empty;
            if (blogCategory.Value == null) return string.Empty;

            //get tag ids
            var blogCategoryValue = blogCategory.Value.ToString();

            if (!string.IsNullOrWhiteSpace(blogCategoryValue))
            {
                var categoryIds = blogCategoryValue.Split('|');
                if (categoryIds.Any())
                {
                    var categoryNames = new List<string>();
                    foreach (var categoryId in categoryIds)
                    {
                        var categoryItem = db.GetItem(new ID(categoryId));
                        if (categoryItem != null)
                        {
                            var categoryType = categoryItem["CategoryType"];
                            categoryNames.Add(categoryType.ToLower().Replace(" ", "-")); //remove space
                        }
                    }
                    return string.Join(" ", categoryNames);
                }
            }
            return string.Empty;
        }
        public string FieldName { get; set; }
        public string ReturnType { get; set; }
    }
}
