﻿using Autofac;
using AutofacDependancyResolver.Core;
using AutofacDependancy.Infrastructure;
using AutofacDependencyResolver.Domain;
using AutoFacDependencyResolver.Repository;

using Sitecore;
using Glass.Mapper.Sc;

namespace AutofacDependancy.DepResolution
{
    public class ServicesModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<SandboxService>().As<ISandboxService>();
            
            //************Resolve Container Bootstrapping Approach**************

            //-------------------- Blog Category ----------------------------------------
            //BlogCategoryRepository blogrepository = new BlogCategoryRepository(new SitecoreService(Context.Database.Name));  
            builder.RegisterType<BlogService>().As<IBlogService>();
            builder.RegisterType<BlogCategoryRepository>().As<IBlogCateogryRepository>();
            builder.Register(c => new SitecoreService(Context.Database.Name)).As<ISitecoreService>().InstancePerLifetimeScope();          
            
            
            //-------------------- Blog List ----------------------------------------------
            builder.Register(c => new IndexResolver(Context.Database.Name)).As<IIndexResolver>().InstancePerLifetimeScope();
            builder.RegisterType<BlogRepository>().As<IBlogRepository>();                                    

            //*********************END*******************
        }
    }
}