
using System;
using Glass.Mapper.Sc;
using Sitecore.Data;
using Sitecore.Data.Managers;

namespace AutoFacDependencyResolver.Repository
{
	public interface ITemplateChecker
	{
		bool IsInheritingFrom(Guid templateId, Guid itemId);
	}

	public class TemplateChecker : ITemplateChecker
	{
		private readonly ISitecoreService _sitecoreService;
		public TemplateChecker(ISitecoreService sitecoreService)
		{
			_sitecoreService = sitecoreService;
		}

		public bool IsInheritingFrom(Guid templateId, Guid itemId)
		{
			var item = _sitecoreService.Database.GetItem(new ID(itemId));
			var template = TemplateManager.GetTemplate(item);
			
			return template.InheritsFrom(new ID(templateId));
		}
	}
}
