namespace AutoFacDependencyResolver.Repository
{
    public class IndexResolver : IIndexResolver
    {
        private const string IndexNameFormat = "zz_{0}_index";
        private readonly string _indexName;

        public IndexResolver(string databaseName)
        {
            _indexName = string.Format(IndexNameFormat, databaseName);
        }
        public string GetIndexName()
        {
            return _indexName;
        }
    }
}
