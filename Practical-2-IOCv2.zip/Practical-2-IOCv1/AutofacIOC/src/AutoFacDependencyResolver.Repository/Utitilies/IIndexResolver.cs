namespace AutoFacDependencyResolver.Repository
{
    public interface IIndexResolver
    {
        string GetIndexName();
    }
}
