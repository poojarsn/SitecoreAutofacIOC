
using System;

namespace AutoFacDependencyResolver.Repository
{
	public static class TemplateId
	{
        public static readonly Guid GenericContent = new Guid("{AA2D1B9A-730D-4C09-8D2A-83FF0F50A0DD}");
	    public static readonly Guid Article = GenericContent;

        //Individual blog Template
        public static readonly Guid Blog = new Guid("{21C10246-F8E8-422F-A4CE-F6F1F262E796}");

        //BlogHome 
        public static readonly Guid BlogList = new Guid("{1EDA6D07-403B-45FC-8909-2E089B9F47C3}");

        //BlogArchive 
        //public static readonly Guid BlogArchive = new Guid("{D8C82BF7-F275-4935-82EB-BAFE8F452739}");

        //Category 
        public static readonly Guid Category = new Guid("{B253D55B-2931-4F0A-8958-9A6347C57FD8}");
	}
}
