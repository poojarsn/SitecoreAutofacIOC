﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoFacDependencyResolver.Repository
{
    public static class StandardValuesItem
    {
       // public const string BlogPageBranchItemId = "{d00aa9a4-25d5-46de-9635-7af3e8b347c9}";
        public const string BlogPageStandarValueItemId = "{3399DFEA-41C5-4138-84A2-8FC1AEE985F8}";
       // public const string TagStandardValueItemId = "{0B27FFB0-7935-4EBA-AA00-88B6A7362431}";
    }
}
