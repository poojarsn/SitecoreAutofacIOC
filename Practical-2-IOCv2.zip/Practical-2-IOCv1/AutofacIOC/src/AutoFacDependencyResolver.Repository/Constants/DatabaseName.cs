
namespace AutoFacDependencyResolver.Repository
{
	public enum DatabaseName
	{
		core,
		master,
		web
	}
}
