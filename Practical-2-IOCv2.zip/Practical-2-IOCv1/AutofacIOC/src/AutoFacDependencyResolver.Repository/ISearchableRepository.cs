using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using AutofacDependencyResolver.Domain;
using Sitecore.ContentSearch.Linq.Common;
using Sitecore.ContentSearch.Linq.Extensions;

namespace AutoFacDependencyResolver.Repository
{
    public interface ISearchableRepository<TEntity> where TEntity : class
    {
        //IEnumerable<TEntity> Search(Expression<Func<TEntity, bool>> expression);
        IEnumerable<TEntity> SearchResult(Expression<Func<TEntity, bool>> expression);
        PagedSearchResult<TEntity> Search(Expression<Func<TEntity, bool>> expression, int pageIndex, int pageSize);

        PagedSearchResult<TEntity> Search<TKey>(Expression<Func<TEntity, bool>> expression, int pageIndex, int pageSize,
            Func<TEntity, TKey> sortExpression, SortDirection sortDirection);

        PagedSearchResult<TEntity> GetPagedResult(Guid parentItemId, int pageIndex, int pageSize);

		PagedSearchResult<TEntity> GetPagedResult<TSortField>(Guid parentItemId, int pageIndex, int pageSize,
															  Func<TEntity, TSortField> sortExpression,
															  SortDirection sortDirection);
	}
}
