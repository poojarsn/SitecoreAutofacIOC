using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using AutofacDependencyResolver.Domain;
using Glass.Mapper.Sc;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.Linq.Common;

namespace AutoFacDependencyResolver.Repository
{
    public abstract class SearchableRepository<T> : Repository<T>, ISearchableRepository<T>
            where T : SitecoreItem, new()
    {
        private readonly string _indexName;

        protected abstract Expression<Func<T, bool>> BasicFilter { get; }

        protected SearchableRepository(ISitecoreService sitecoreService, IIndexResolver resolver)
            : base(sitecoreService)
        {
            _indexName = resolver.GetIndexName();
        }

		public IEnumerable<T> Search(Expression<Func<T, bool>> expression)
		{
			using (var context = ContentSearchManager.GetIndex(_indexName).CreateSearchContext())
			{
				//return context.GetQueryable<T>().Where(expression).ToList();
                var result= context.GetQueryable<T>().Where(expression).ToList();
                return result;
			}
		}

        public IEnumerable<T> SearchResult(Expression<Func<T, bool>> expression)
        {
            var luceneItems = Search(expression);
            return luceneItems.Select(a => Get(a.SitecoreItemId)).ToList();
        }

		public PagedSearchResult<T> Search(Expression<Func<T, bool>> expression, int pageIndex, int pageSize)
		{
			return Search<string>(expression, pageIndex, pageSize, null, SortDirection.Ascending);
		}

        public PagedSearchResult<T> GetPagedResult(Guid parentItemId, int pageIndex, int pageSize)
		{
			return Search(BasicFilter, pageIndex, pageSize);
		}

	    public PagedSearchResult<T> GetPagedResult<TSortField>(Guid parentItemId, int pageIndex, int pageSize,
	                                                           Func<T, TSortField> sortExpression,
	                                                           SortDirection sortDirection)
	    {
		    return Search(BasicFilter, pageIndex, pageSize, sortExpression, sortDirection);
	    }

	    public PagedSearchResult<T> Search<TKey>(Expression<Func<T, bool>> expression, int pageIndex, int pageSize,
	                                             Func<T, TKey> sortExpression, SortDirection sortDirection)
	    {
		    using (var context = ContentSearchManager.GetIndex(_indexName).CreateSearchContext())
		    {
				IEnumerable<T> luceneItems = context.GetQueryable<T>().Where(BasicFilter).Where(expression);

				if (sortExpression != null)
				{
					switch (sortDirection)
					{
						case SortDirection.Ascending:
							{
								luceneItems = luceneItems.OrderBy(sortExpression);
								break;
							}
						case SortDirection.Descending:
							{
								luceneItems = luceneItems.OrderByDescending(sortExpression);
								break;
							}
					}
				}

				var count = luceneItems.Count();
				luceneItems = luceneItems.
					Skip((pageIndex - 1) * pageSize).
					Take(pageSize).ToList();

                var glassItems = luceneItems.Select(GetGlassMapperItem);
				return new PagedSearchResult<T>
					{
						PageIndex = pageIndex,
						ItemCount = count,
						PageSize = pageSize,
						Items = glassItems.ToList()
					};
		    }
	    }

        protected virtual T GetGlassMapperItem(T item)
        {
            return Get(item.SitecoreItemId);
        }
    }
}
