using System;
using System.Collections.Generic;

namespace AutoFacDependencyResolver.Repository
{
	public interface IRepository<T> where T : class
	{
		T Get(Guid itemId);
		T Get(string query);
		IEnumerable<T> GetAll(Guid folderId);
		IEnumerable<T> GetAll(string query);
		T Add(string parentItemPath, T item);
		T Add(Guid parentItemId, T item);
		void Update(T item);
		void Delete(T item);
	}
}
