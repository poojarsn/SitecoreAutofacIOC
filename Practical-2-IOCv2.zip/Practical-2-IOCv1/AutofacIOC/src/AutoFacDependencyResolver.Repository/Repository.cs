
using System;
using System.Collections.Generic;
using AutofacDependencyResolver.Domain;
using Glass.Mapper.Sc;
using System.Linq;

namespace AutoFacDependencyResolver.Repository
{
	public class Repository<T> : IRepository<T> where T : class
	{
	    private readonly ISitecoreService _sitecoreService;

		public Repository(ISitecoreService sitecoreService)
		{
		    _sitecoreService = sitecoreService;
		}

        protected ISitecoreService Context
        {
            get { return _sitecoreService; }
        }

		public T Get(Guid itemId)
		{
            return Context.GetItem<T>(itemId);
		}

		public T Get(string query)
		{
			return Context.QuerySingle<T>(query);
		}

		public IEnumerable<T> GetAll(Guid folderId)
		{
			var folder = Context.GetItem<FolderItem<T>>(folderId);
			if (folder != null)
			{
				return folder.Children.ToList();				
			}

			return new List<T>();
		}

		public IEnumerable<T> GetAll(string query)
		{
			return Context.Query<T>(query);
		}

		public T Add(string parentItemPath, T item)
		{
			var parentItem = Context.GetItem<SitecoreItem>(parentItemPath);
			if (parentItem != null)
			{
				return Context.Create(parentItem, item);
			}

			return null;
		}

		public T Add(Guid parentItemId, T item)
		{
			var parentItem = Context.GetItem<SitecoreItem>(parentItemId);
			if (parentItem != null)
			{
				return Context.Create(parentItem, item);
			}

			return null;
		}

		public void Update(T item)
		{
			Context.Save(item);			
		}

		public void Delete(T item)
		{
			Context.Delete(item);
		}
	}
}
