using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using AutofacDependencyResolver.Domain;
using Glass.Mapper.Sc;
using Sitecore.ContentSearch.Linq.Common;
using scSearch = Sitecore.ContentSearch;

namespace AutoFacDependencyResolver.Repository
{
    public class BlogCategoryRepository : Repository<BlogCategory>, IBlogCateogryRepository
    {
        public BlogCategoryRepository(ISitecoreService sitecoreService): base(sitecoreService)
        {
        }

        public IEnumerable<BlogCategory> GetBlogCategory(Guid parentItemId)
        {
            return GetAll(parentItemId);
        }
	}
}
