using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using AutofacDependencyResolver.Domain;
using Glass.Mapper.Sc;
using Sitecore.ContentSearch.Linq.Common;
using scSearch = Sitecore.ContentSearch;
using Sitecore.Links;

namespace AutoFacDependencyResolver.Repository
{
    public class BlogRepository : SearchableRepository<BlogItem>, IBlogRepository
    {
        public BlogRepository(ISitecoreService sitecoreService, IIndexResolver resolver) 
            : base(sitecoreService, resolver)
        {
        }

        protected override Expression<Func<BlogItem, bool>> BasicFilter
        {
            get { return a => a.SitecoreTemplateId == TemplateId.Blog
                && a.SitecoreItemId != new Guid(StandardValuesItem.BlogPageStandarValueItemId) ;
                //need to check branch Item concepts Here.
                //&& a.SitecoreItemId != new Guid(StandardValuesItem.BlogPageBranchItemId);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="parentItemId"></param>
        /// <returns></returns>
        public IEnumerable<BlogItem> GetAllBlogs(Guid parentItemId)
        {
            var parent = Context.GetItem<SitecoreItem>(parentItemId);
            var blogs= Search(a => a.SitecoreTemplateId == TemplateId.Blog
                               && a.SitecoreItemPath.StartsWith(parent.SitecoreItemPath)
                               && a.SitecoreItemId != new Guid(StandardValuesItem.BlogPageStandarValueItemId));
            blogs.Select(c => {c.SitecoreItemUrl = LinkManager.GetItemUrl(Sitecore.Context.Database.GetItem(c.SitecoreItemPath)).ToString() ; return c;}).ToList();
            return blogs;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="TSortField"></typeparam>
        /// <param name="parentItemId"></param>
        /// <param name="tagName"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortExpression"></param>
        /// <param name="sortDirection"></param>
        /// <returns></returns>
		public PagedSearchResult<BlogItem> GetBlogByTag<TSortField>(Guid parentItemId, string tagName, int pageIndex,
																	int pageSize, Func<BlogItem, TSortField> sortExpression,
																	SortDirection sortDirection)
		{
			var parent = Context.GetItem<SitecoreItem>(parentItemId);

			return Search(a => a.SitecoreTemplateId == TemplateId.Blog
							   && a.SitecoreItemPath.StartsWith(parent.SitecoreItemPath)
                               && a.SitecoreItemName != "__Standard Values", pageIndex, pageSize, sortExpression, sortDirection);
		}

        public PagedSearchResult<BlogItem> GetBlogByCategory<TSortField>(Guid parentItemId, string categoryName, int pageIndex,
                                                                    int pageSize, Func<BlogItem, TSortField> sortExpression,
                                                                    SortDirection sortDirection)
        {
            var parent = Context.GetItem<SitecoreItem>(parentItemId);

            return Search(a => a.SitecoreTemplateId == TemplateId.Blog
                               && a.SitecoreItemPath.StartsWith(parent.SitecoreItemPath)
                               && (a.RawCategories == categoryName)
                               && a.SitecoreItemName != "__Standard Values", pageIndex, pageSize, sortExpression, sortDirection);
        }

        public PagedSearchResult<BlogItem> GetRelatedBlogByCategory<TSortField>(Guid parentItemId, string categoryName, int pageIndex,
                                                                    int pageSize, Func<BlogItem, TSortField> sortExpression,
                                                                    SortDirection sortDirection)
        {
            var parent = Context.GetItem<SitecoreItem>(parentItemId);

            return Search(a => a.SitecoreTemplateId == TemplateId.Blog
                               && a.SitecoreItemPath != parent.SitecoreItemPath
                               && (a.RawCategories == categoryName), 
                               pageIndex, pageSize, sortExpression, sortDirection);
        }

        public PagedSearchResult<BlogItem> GetRelatedBlogByDate<TSortField>(Guid parentItemId,string yearMonth, int pageIndex,
                                                                    int pageSize, Func<BlogItem, TSortField> sortExpression,
                                                                    SortDirection sortDirection)
        {
            var parent = Context.GetItem<SitecoreItem>(parentItemId);

            return Search(a => a.SitecoreTemplateId == TemplateId.Blog
                               && a.SitecoreItemPath != parent.SitecoreItemPath
                               && (a.RawPostDate.StartsWith(yearMonth)),
                               pageIndex, pageSize, sortExpression, sortDirection);
        }

        public IEnumerable<BlogItem> GetAllBlogsList(Guid parentItemId)
        {
            return GetAll(parentItemId);
        }
	}
}
