using System;
using System.Collections.Generic;
using AutofacDependencyResolver.Domain;
using Sitecore.ContentSearch.Linq.Common;

namespace AutoFacDependencyResolver.Repository
{
	public interface IBlogCateogryRepository 
	{
        IEnumerable<BlogCategory> GetBlogCategory(Guid parentItemId);
	}
}