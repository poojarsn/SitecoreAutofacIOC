using System;
using System.Collections.Generic;
using AutofacDependencyResolver.Domain;
using Sitecore.ContentSearch.Linq.Common;

namespace AutoFacDependencyResolver.Repository
{
	public interface IBlogRepository : IRepository<BlogItem>, ISearchableRepository<BlogItem>
	{
		PagedSearchResult<BlogItem> GetBlogByTag<TSortField>(Guid parentItemId, string tagName, int pageIndex, int pageSize,
		                                                     Func<BlogItem, TSortField> sortExpression,
		                                                     SortDirection sortDirection);

        PagedSearchResult<BlogItem> GetBlogByCategory<TSortField>(Guid parentItemId, string categoryName, int pageIndex,
                                                                    int pageSize, Func<BlogItem, TSortField> sortExpression,
                                                                    SortDirection sortDirection);

        PagedSearchResult<BlogItem> GetRelatedBlogByCategory<TSortField>(Guid parentItemId, string categoryName, int pageIndex,
                                                                    int pageSize, Func<BlogItem, TSortField> sortExpression,
                                                                    SortDirection sortDirection);

	    PagedSearchResult<BlogItem> GetRelatedBlogByDate<TSortField>(Guid parentItemId, string yearMonth, int pageIndex,
	                                                                int pageSize, Func<BlogItem, TSortField> sortExpression,
	                                                                SortDirection sortDirection);

	    IEnumerable<BlogItem> GetAllBlogs(Guid parentItemId);

        IEnumerable<BlogItem> GetAllBlogsList(Guid parentItemId);
	}
}