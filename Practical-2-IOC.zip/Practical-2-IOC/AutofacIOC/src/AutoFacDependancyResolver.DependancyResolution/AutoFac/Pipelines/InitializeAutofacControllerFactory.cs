﻿using System.Web.Mvc;
using Autofac.Integration.Mvc;

using Sitecore.Pipelines;

namespace AutofacDependancy.DepResolution
{
    public class InitializeAutofacControllerFactory
    {
        public virtual void Process(PipelineArgs args)
        {
            SetControllerFactory(args);
        }

        private void SetControllerFactory(PipelineArgs args)
        {
            var containerFactory = new AutofacContainerFactory();
            var container = containerFactory.Create();
            DependencyResolver.SetResolver(new AutofacDependencyResolver(container));
            var controllerFactory = new AutofacControllerFactory(container);
            ControllerBuilder.Current.SetControllerFactory(controllerFactory);
        }
    }
}