﻿using Autofac;
using AutofacDependancyResolver.Core;
using AutofacDependancy.Infrastructure;

namespace AutofacDependancy.DepResolution
{
    public class ServicesModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<SandboxService>().As<ISandboxService>();
        }
    }
}