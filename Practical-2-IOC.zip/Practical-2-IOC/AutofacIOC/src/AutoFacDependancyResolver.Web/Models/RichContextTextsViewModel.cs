﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AutofacDependancy.Web
{
    public class RichContextTextsViewModel
    {
        public IList<WYSIWYG> WYSIWYGs { get; set; }
    }
}